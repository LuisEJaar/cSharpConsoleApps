﻿namespace ChangeCase
{
    internal enum Case
    {
        Upper,
        Lower
    }
}