﻿namespace CLParserEnums
{
    enum SortOrder
    {
        Default,
        Ascending,
        Descending
    }
}