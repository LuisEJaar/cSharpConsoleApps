﻿using CommandLine;

namespace CLImplicitArgumentNames
{
    class MyOptions
    {
        [Option]
        public string Name { get; set; }
    }
}